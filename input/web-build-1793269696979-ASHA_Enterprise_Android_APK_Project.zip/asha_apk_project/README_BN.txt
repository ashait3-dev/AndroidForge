আশা এন্টারপ্রাইজ ERP — Android APK তৈরির প্রজেক্ট
=================================================

এই ফোল্ডারটি Android Studio-তে খোলার মতো একটি Android WebView প্রজেক্ট। এতে আপনার দেওয়া PWA-এর web ফাইল assets/www/ এর মধ্যে রাখা হয়েছে। এটি এখনো কম্পাইল করা APK নয়। এই পরিবেশে Android SDK/Gradle নেই, তাই এখানে ইনস্টলযোগ্য APK তৈরি/পরীক্ষা করা সম্ভব হয়নি।

APK তৈরির জন্য
--------------
১. Windows কম্পিউটারে Android Studio (stable) ইনস্টল করুন।
২. ZIP extract করুন। Android Studio → Open → এই ফোল্ডার `asha_apk_project` নির্বাচন করুন.
৩. Gradle sync করতে দিন. Android SDK Platform 35 ইনস্টল করতে বললে SDK Manager থেকে ইনস্টল করুন.
৪. Build → Build Bundle(s) / APK(s) → Build APK(s) নির্বাচন করুন.
৫. Build সফল হলে APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk` এ পাওয়া যাবে.
৬. APK ফোনে পাঠিয়ে ইনস্টল করতে Android-এ ওই ফাইল/অ্যাপের জন্য Install unknown apps অনুমতি দিন; শুধুমাত্র নিজের বিশ্বস্ত APK ইনস্টল করুন.

ক্যামেরা
--------
অ্যাপটি Android WebViewAssetLoader-এর HTTPS-ধাঁচের appassets origin ব্যবহার করে এবং ক্যামেরার runtime permission চায়। ডিভাইসে ইনস্টল করে ক্যামেরা স্ক্যান বাস্তবে পরীক্ষা করতে হবে। ব্রাউজার/ডিভাইস ও বারকোড ফরম্যাট অনুযায়ী ফল আলাদা হতে পারে।

গুরুত্বপূর্ণ সীমাবদ্ধতা
---------------------
• এই APK-তে ডেটা স্থানীয়ভাবে থাকতে পারে; শুধু APK ইনস্টল করলেই মাল্টিপল ইউজারের কেন্দ্রীয় সিঙ্ক তৈরি হয় না।
• আগের প্যাকেজের Google OAuth/Drive সিঙ্ক embedded WebView-তে Google-এর নিরাপত্তা নীতির কারণে কাজ নাও করতে পারে। নির্ভরযোগ্য multi-user ব্যবহারের জন্য Firebase/Supabase বা নিজস্ব backend-এ server-side authentication ও shared database যুক্ত করতে হবে, অথবা HTTPS হোস্ট করা PWA Chrome-এ চালাতে হবে।
• এই প্রজেক্টটি debug APK তৈরি করার ভিত্তি। Release APK বিতরণের আগে signing key, ব্যাকআপ, ডেটা-সুরক্ষা, এবং login/permissions পরীক্ষা জরুরি।
• Google OAuth Client ID, backend credentials বা signing key এই প্রজেক্টে অন্তর্ভুক্ত নেই। এগুলো কখনো প্রকাশ্যে শেয়ার করবেন না।
